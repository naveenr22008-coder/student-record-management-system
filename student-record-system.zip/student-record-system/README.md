# Student Record Management System

A full-stack CRUD app for managing student records.

- **Backend:** Node.js + Express + SQLite (via `better-sqlite3`)
- **Frontend:** React + Vite

## Features

- Add, view, edit, and delete student records (roll no., name, email, phone,
  DOB, gender, course, year, address)
- Search by name, roll number, or email
- Filter by course and year
- Sortable columns, pagination
- Server-side validation (required fields, email format, unique roll
  no./email, year range) with inline error messages
- Toast notifications for success/error feedback

## Project structure

```
student-record-system/
├── backend/
│   ├── server.js          # Express app entry point
│   ├── db.js               # SQLite connection + schema
│   ├── routes/students.js  # CRUD API routes
│   └── package.json
└── frontend/
    ├── index.html
    ├── src/
    │   ├── App.jsx
    │   ├── api.js           # fetch wrapper for the API
    │   ├── index.css
    │   └── components/
    │       ├── StudentTable.jsx
    │       ├── StudentFormModal.jsx
    │       └── Toast.jsx
    └── package.json
```

## Setup

You'll need [Node.js](https://nodejs.org) 18+ installed.

### 1. Backend

```bash
cd backend
npm install
npm start
```

This starts the API on **http://localhost:4000**. A `students.db` SQLite
file is created automatically in the `backend/` folder on first run — no
separate database setup needed.

### 2. Frontend

In a second terminal:

```bash
cd frontend
npm install
npm run dev
```

This starts the app on **http://localhost:5173**. Vite is configured to
proxy `/api` requests to the backend on port 4000, so no CORS config is
needed on the client side (though the backend also has `cors` enabled).

Open http://localhost:5173 in your browser.

## API reference

| Method | Endpoint                     | Description                          |
|--------|-------------------------------|--------------------------------------|
| GET    | `/api/students`               | List students (query: `search`, `course`, `year`, `sort`, `order`, `page`, `limit`) |
| GET    | `/api/students/:id`           | Get one student                      |
| POST   | `/api/students`               | Create a student                     |
| PUT    | `/api/students/:id`           | Update a student                     |
| DELETE | `/api/students/:id`           | Delete a student                     |
| GET    | `/api/students/meta/courses`  | Distinct list of courses on file     |

### Student object

```json
{
  "id": 1,
  "roll_no": "CS2024001",
  "first_name": "Asha",
  "last_name": "Rao",
  "email": "asha.rao@example.com",
  "phone": "9876543210",
  "dob": "2004-03-12",
  "gender": "female",
  "course": "B.Sc. Computer Science",
  "year": 2,
  "address": "12 MG Road, Madurai",
  "created_at": "2026-07-14 10:00:00",
  "updated_at": "2026-07-14 10:00:00"
}
```

`roll_no` and `email` must be unique. `roll_no`, `first_name`, `last_name`,
`email`, `course`, and `year` are required on create.

## Notes / next steps

- For production, swap `npm run dev` for `npm run build` in `frontend/`
  and serve the built static files (e.g. from Express or a static host).
- Add authentication/authorization if this will be exposed beyond a
  trusted local network — there is currently none.
- `better-sqlite3` is a native module; if `npm install` fails to build it,
  make sure you have a C++ build toolchain available (Xcode Command Line
  Tools on macOS, `build-essential` on Debian/Ubuntu, or the Node.js
  build tools on Windows).
