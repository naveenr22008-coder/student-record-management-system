const express = require("express");
const router = express.Router();
const db = require("../db");

// Helper: format validation errors
function validateStudent(body, isUpdate = false) {
  const errors = [];
  const required = ["roll_no", "first_name", "last_name", "email", "course", "year"];

  if (!isUpdate) {
    for (const field of required) {
      if (!body[field] || String(body[field]).trim() === "") {
        errors.push(`${field} is required`);
      }
    }
  }

  if (body.email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(body.email)) {
    errors.push("email is not valid");
  }

  if (body.year !== undefined && body.year !== null && body.year !== "") {
    const y = Number(body.year);
    if (!Number.isInteger(y) || y < 1 || y > 8) {
      errors.push("year must be an integer between 1 and 8");
    }
  }

  return errors;
}

// GET /api/students - list all, with optional search & pagination
router.get("/", (req, res) => {
  const { search = "", course = "", year = "", sort = "id", order = "ASC", page = 1, limit = 20 } = req.query;

  const validSortCols = ["id", "roll_no", "first_name", "last_name", "email", "course", "year", "created_at"];
  const sortCol = validSortCols.includes(sort) ? sort : "id";
  const sortOrder = order.toUpperCase() === "DESC" ? "DESC" : "ASC";

  let where = [];
  let params = {};

  if (search) {
    where.push("(first_name LIKE @search OR last_name LIKE @search OR roll_no LIKE @search OR email LIKE @search)");
    params.search = `%${search}%`;
  }
  if (course) {
    where.push("course = @course");
    params.course = course;
  }
  if (year) {
    where.push("year = @year");
    params.year = Number(year);
  }

  const whereClause = where.length ? `WHERE ${where.join(" AND ")}` : "";

  const total = db.prepare(`SELECT COUNT(*) as count FROM students ${whereClause}`).get(params).count;

  const offset = (Math.max(1, Number(page)) - 1) * Number(limit);
  const rows = db
    .prepare(`SELECT * FROM students ${whereClause} ORDER BY ${sortCol} ${sortOrder} LIMIT @limit OFFSET @offset`)
    .all({ ...params, limit: Number(limit), offset });

  res.json({ data: rows, total, page: Number(page), limit: Number(limit) });
});

// GET /api/students/:id
router.get("/:id", (req, res) => {
  const student = db.prepare("SELECT * FROM students WHERE id = ?").get(req.params.id);
  if (!student) return res.status(404).json({ error: "Student not found" });
  res.json(student);
});

// POST /api/students - create
router.post("/", (req, res) => {
  const errors = validateStudent(req.body);
  if (errors.length) return res.status(400).json({ errors });

  const { roll_no, first_name, last_name, email, phone, dob, gender, course, year, address } = req.body;

  try {
    const stmt = db.prepare(`
      INSERT INTO students (roll_no, first_name, last_name, email, phone, dob, gender, course, year, address)
      VALUES (@roll_no, @first_name, @last_name, @email, @phone, @dob, @gender, @course, @year, @address)
    `);
    const info = stmt.run({
      roll_no, first_name, last_name, email,
      phone: phone || null, dob: dob || null, gender: gender || null,
      course, year: Number(year), address: address || null,
    });
    const student = db.prepare("SELECT * FROM students WHERE id = ?").get(info.lastInsertRowid);
    res.status(201).json(student);
  } catch (err) {
    if (err.code === "SQLITE_CONSTRAINT_UNIQUE") {
      return res.status(409).json({ errors: ["roll_no or email already exists"] });
    }
    res.status(500).json({ errors: [err.message] });
  }
});

// PUT /api/students/:id - update
router.put("/:id", (req, res) => {
  const existing = db.prepare("SELECT * FROM students WHERE id = ?").get(req.params.id);
  if (!existing) return res.status(404).json({ error: "Student not found" });

  const errors = validateStudent(req.body, true);
  if (errors.length) return res.status(400).json({ errors });

  const merged = { ...existing, ...req.body };

  try {
    db.prepare(`
      UPDATE students SET
        roll_no = @roll_no, first_name = @first_name, last_name = @last_name,
        email = @email, phone = @phone, dob = @dob, gender = @gender,
        course = @course, year = @year, address = @address,
        updated_at = datetime('now')
      WHERE id = @id
    `).run({ ...merged, id: req.params.id, year: Number(merged.year) });

    const updated = db.prepare("SELECT * FROM students WHERE id = ?").get(req.params.id);
    res.json(updated);
  } catch (err) {
    if (err.code === "SQLITE_CONSTRAINT_UNIQUE") {
      return res.status(409).json({ errors: ["roll_no or email already exists"] });
    }
    res.status(500).json({ errors: [err.message] });
  }
});

// DELETE /api/students/:id
router.delete("/:id", (req, res) => {
  const existing = db.prepare("SELECT * FROM students WHERE id = ?").get(req.params.id);
  if (!existing) return res.status(404).json({ error: "Student not found" });

  db.prepare("DELETE FROM students WHERE id = ?").run(req.params.id);
  res.status(204).send();
});

// GET /api/students-meta/courses - distinct course list (used for filter dropdown)
router.get("/meta/courses", (req, res) => {
  const rows = db.prepare("SELECT DISTINCT course FROM students ORDER BY course").all();
  res.json(rows.map((r) => r.course));
});

module.exports = router;
