const Database = require("better-sqlite3");
const path = require("path");

const db = new Database(path.join(__dirname, "students.db"));

db.pragma("journal_mode = WAL");

db.exec(`
  CREATE TABLE IF NOT EXISTS students (
    id           INTEGER PRIMARY KEY AUTOINCREMENT,
    roll_no      TEXT NOT NULL UNIQUE,
    first_name   TEXT NOT NULL,
    last_name    TEXT NOT NULL,
    email        TEXT NOT NULL UNIQUE,
    phone        TEXT,
    dob          TEXT,
    gender       TEXT,
    course       TEXT NOT NULL,
    year         INTEGER NOT NULL,
    address      TEXT,
    created_at   TEXT DEFAULT (datetime('now')),
    updated_at   TEXT DEFAULT (datetime('now'))
  );
`);

module.exports = db;
