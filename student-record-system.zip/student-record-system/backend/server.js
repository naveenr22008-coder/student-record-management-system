const express = require("express");
const cors = require("cors");
const studentsRouter = require("./routes/students");

const app = express();
const PORT = process.env.PORT || 4000;

app.use(cors());
app.use(express.json());

app.use("/api/students", studentsRouter);

app.get("/api/health", (req, res) => res.json({ status: "ok" }));

app.use((req, res) => res.status(404).json({ error: "Not found" }));

app.listen(PORT, () => {
  console.log(`Student Record API listening on http://localhost:${PORT}`);
});
