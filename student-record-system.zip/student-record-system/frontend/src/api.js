const BASE = "/api/students";

async function handle(res) {
  if (res.status === 204) return null;
  const body = await res.json().catch(() => ({}));
  if (!res.ok) {
    const message = (body.errors && body.errors.join(", ")) || body.error || "Request failed";
    throw new Error(message);
  }
  return body;
}

export const api = {
  list(params = {}) {
    const qs = new URLSearchParams(
      Object.fromEntries(Object.entries(params).filter(([, v]) => v !== "" && v != null))
    ).toString();
    return fetch(`${BASE}?${qs}`).then(handle);
  },
  get(id) {
    return fetch(`${BASE}/${id}`).then(handle);
  },
  create(data) {
    return fetch(BASE, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(data),
    }).then(handle);
  },
  update(id, data) {
    return fetch(`${BASE}/${id}`, {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(data),
    }).then(handle);
  },
  remove(id) {
    return fetch(`${BASE}/${id}`, { method: "DELETE" }).then(handle);
  },
  courses() {
    return fetch(`${BASE}/meta/courses`).then(handle);
  },
};
