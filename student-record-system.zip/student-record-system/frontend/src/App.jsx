import { useEffect, useState, useCallback } from "react";
import { api } from "./api";
import StudentTable from "./components/StudentTable";
import StudentFormModal from "./components/StudentFormModal";
import Toast from "./components/Toast";

const PAGE_SIZE = 10;

export default function App() {
  const [students, setStudents] = useState([]);
  const [total, setTotal] = useState(0);
  const [page, setPage] = useState(1);
  const [search, setSearch] = useState("");
  const [courseFilter, setCourseFilter] = useState("");
  const [yearFilter, setYearFilter] = useState("");
  const [courses, setCourses] = useState([]);
  const [sort, setSort] = useState("id");
  const [order, setOrder] = useState("DESC");
  const [loading, setLoading] = useState(true);
  const [modalState, setModalState] = useState(null); // null | "new" | studentObj
  const [toast, setToast] = useState(null);

  const showToast = (message, type = "success") => {
    setToast({ message, type });
    setTimeout(() => setToast(null), 2600);
  };

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const res = await api.list({
        search,
        course: courseFilter,
        year: yearFilter,
        sort,
        order,
        page,
        limit: PAGE_SIZE,
      });
      setStudents(res.data);
      setTotal(res.total);
    } catch (err) {
      showToast(err.message, "error");
    } finally {
      setLoading(false);
    }
  }, [search, courseFilter, yearFilter, sort, order, page]);

  useEffect(() => {
    load();
  }, [load]);

  useEffect(() => {
    api.courses().then(setCourses).catch(() => {});
  }, [modalState]);

  useEffect(() => {
    setPage(1);
  }, [search, courseFilter, yearFilter]);

  function handleSort(col) {
    if (sort === col) {
      setOrder((o) => (o === "ASC" ? "DESC" : "ASC"));
    } else {
      setSort(col);
      setOrder("ASC");
    }
  }

  async function handleSave(form) {
    const isEdit = modalState && modalState !== "new";
    if (isEdit) {
      await api.update(modalState.id, form);
      showToast("Student record updated");
    } else {
      await api.create(form);
      showToast("Student added");
    }
    setModalState(null);
    load();
  }

  async function handleDelete(student) {
    if (!window.confirm(`Delete the record for ${student.first_name} ${student.last_name}? This can't be undone.`)) {
      return;
    }
    try {
      await api.remove(student.id);
      showToast("Student record deleted");
      load();
    } catch (err) {
      showToast(err.message, "error");
    }
  }

  const totalPages = Math.max(1, Math.ceil(total / PAGE_SIZE));
  const distinctYears = [1, 2, 3, 4, 5, 6];

  return (
    <div className="app">
      <header className="masthead">
        <div>
          <h1 className="masthead-title">Student Records</h1>
          <div className="masthead-sub">REGISTER · {new Date().getFullYear()} INTAKE</div>
        </div>
        <button className="btn btn-primary" onClick={() => setModalState("new")}>
          + Add student
        </button>
      </header>

      <section className="stats">
        <div className="stat-card">
          <div className="stat-label">Total students</div>
          <div className="stat-value">{total}</div>
        </div>
        <div className="stat-card">
          <div className="stat-label">Courses</div>
          <div className="stat-value">{courses.length}</div>
        </div>
        <div className="stat-card">
          <div className="stat-label">Showing</div>
          <div className="stat-value">{students.length}</div>
        </div>
        <div className="stat-card">
          <div className="stat-label">Page</div>
          <div className="stat-value">
            {page} / {totalPages}
          </div>
        </div>
      </section>

      <div className="toolbar">
        <input
          className="input search-input"
          placeholder="Search by name, roll no. or email…"
          value={search}
          onChange={(e) => setSearch(e.target.value)}
        />
        <select className="select" value={courseFilter} onChange={(e) => setCourseFilter(e.target.value)}>
          <option value="">All courses</option>
          {courses.map((c) => (
            <option key={c} value={c}>
              {c}
            </option>
          ))}
        </select>
        <select className="select" value={yearFilter} onChange={(e) => setYearFilter(e.target.value)}>
          <option value="">All years</option>
          {distinctYears.map((y) => (
            <option key={y} value={y}>
              Year {y}
            </option>
          ))}
        </select>
      </div>

      {loading ? (
        <div className="ledger">
          <div className="empty-state">Loading records…</div>
        </div>
      ) : (
        <StudentTable
          students={students}
          sort={sort}
          order={order}
          onSort={handleSort}
          onEdit={setModalState}
          onDelete={handleDelete}
        />
      )}

      <div className="pagination">
        <span>
          {total === 0 ? "0 records" : `Showing ${(page - 1) * PAGE_SIZE + 1}–${Math.min(page * PAGE_SIZE, total)} of ${total}`}
        </span>
        <div className="pagination-controls">
          <button className="page-btn" disabled={page <= 1} onClick={() => setPage((p) => p - 1)}>
            Previous
          </button>
          <button className="page-btn" disabled={page >= totalPages} onClick={() => setPage((p) => p + 1)}>
            Next
          </button>
        </div>
      </div>

      {modalState && (
        <StudentFormModal
          student={modalState === "new" ? null : modalState}
          onClose={() => setModalState(null)}
          onSave={handleSave}
        />
      )}

      <Toast message={toast?.message} type={toast?.type} />
    </div>
  );
}
