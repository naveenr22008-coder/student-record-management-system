import { useState } from "react";

const empty = {
  roll_no: "",
  first_name: "",
  last_name: "",
  email: "",
  phone: "",
  dob: "",
  gender: "",
  course: "",
  year: "",
  address: "",
};

export default function StudentFormModal({ student, onClose, onSave }) {
  const [form, setForm] = useState(student ? { ...empty, ...student } : empty);
  const [error, setError] = useState("");
  const [saving, setSaving] = useState(false);
  const isEdit = Boolean(student);

  function update(field, value) {
    setForm((f) => ({ ...f, [field]: value }));
  }

  async function handleSubmit(e) {
    e.preventDefault();
    setError("");
    setSaving(true);
    try {
      await onSave(form);
    } catch (err) {
      setError(err.message);
    } finally {
      setSaving(false);
    }
  }

  return (
    <div className="modal-backdrop" onMouseDown={(e) => e.target === e.currentTarget && onClose()}>
      <div className="modal">
        <div className="modal-header">
          <h2 className="modal-title">{isEdit ? "Edit student record" : "New student record"}</h2>
          <button className="modal-close" onClick={onClose} aria-label="Close">
            ×
          </button>
        </div>

        {error && <div className="form-error">{error}</div>}

        <form onSubmit={handleSubmit}>
          <div className="form-grid">
            <div className="form-field">
              <label className="form-label">Roll number</label>
              <input
                className="input"
                value={form.roll_no}
                onChange={(e) => update("roll_no", e.target.value)}
                required
              />
            </div>
            <div className="form-field">
              <label className="form-label">Course</label>
              <input
                className="input"
                value={form.course}
                onChange={(e) => update("course", e.target.value)}
                placeholder="e.g. B.Sc. Computer Science"
                required
              />
            </div>

            <div className="form-field">
              <label className="form-label">First name</label>
              <input
                className="input"
                value={form.first_name}
                onChange={(e) => update("first_name", e.target.value)}
                required
              />
            </div>
            <div className="form-field">
              <label className="form-label">Last name</label>
              <input
                className="input"
                value={form.last_name}
                onChange={(e) => update("last_name", e.target.value)}
                required
              />
            </div>

            <div className="form-field">
              <label className="form-label">Email</label>
              <input
                className="input"
                type="email"
                value={form.email}
                onChange={(e) => update("email", e.target.value)}
                required
              />
            </div>
            <div className="form-field">
              <label className="form-label">Phone</label>
              <input className="input" value={form.phone || ""} onChange={(e) => update("phone", e.target.value)} />
            </div>

            <div className="form-field">
              <label className="form-label">Year</label>
              <select className="select" value={form.year} onChange={(e) => update("year", e.target.value)} required>
                <option value="">Select year</option>
                {[1, 2, 3, 4, 5, 6].map((y) => (
                  <option key={y} value={y}>
                    Year {y}
                  </option>
                ))}
              </select>
            </div>
            <div className="form-field">
              <label className="form-label">Date of birth</label>
              <input className="input" type="date" value={form.dob || ""} onChange={(e) => update("dob", e.target.value)} />
            </div>

            <div className="form-field">
              <label className="form-label">Gender</label>
              <select className="select" value={form.gender || ""} onChange={(e) => update("gender", e.target.value)}>
                <option value="">Prefer not to say</option>
                <option value="female">Female</option>
                <option value="male">Male</option>
                <option value="other">Other</option>
              </select>
            </div>
            <div className="form-field">
              <label className="form-label">&nbsp;</label>
            </div>

            <div className="form-field full">
              <label className="form-label">Address</label>
              <input className="input" value={form.address || ""} onChange={(e) => update("address", e.target.value)} />
            </div>
          </div>

          <div className="modal-footer">
            <button type="button" className="btn btn-ghost" onClick={onClose}>
              Cancel
            </button>
            <button type="submit" className="btn btn-primary" disabled={saving}>
              {saving ? "Saving…" : isEdit ? "Save changes" : "Add student"}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
