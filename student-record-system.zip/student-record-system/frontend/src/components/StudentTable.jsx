export default function StudentTable({ students, sort, order, onSort, onEdit, onDelete }) {
  const columns = [
    { key: "roll_no", label: "Roll no." },
    { key: "first_name", label: "Name" },
    { key: "course", label: "Course" },
    { key: "year", label: "Year" },
    { key: "email", label: "Contact" },
  ];

  function sortIndicator(key) {
    if (sort !== key) return "";
    return order === "ASC" ? " ↑" : " ↓";
  }

  if (students.length === 0) {
    return (
      <div className="ledger">
        <div className="empty-state">
          <div className="empty-state-title">No records match</div>
          <div>Try clearing filters, or add a new student to get started.</div>
        </div>
      </div>
    );
  }

  return (
    <div className="ledger">
      <table>
        <thead>
          <tr>
            {columns.map((col) => (
              <th key={col.key} onClick={() => onSort(col.key)}>
                {col.label}
                {sortIndicator(col.key)}
              </th>
            ))}
            <th style={{ textAlign: "right" }}>Actions</th>
          </tr>
        </thead>
        <tbody>
          {students.map((s) => (
            <tr key={s.id}>
              <td>
                <span className="roll-chip">{s.roll_no}</span>
              </td>
              <td>
                <div className="name-cell">
                  {s.first_name} {s.last_name}
                </div>
              </td>
              <td>{s.course}</td>
              <td>
                <span className="year-chip">Yr {s.year}</span>
              </td>
              <td>
                <div>{s.email}</div>
                {s.phone && <div className="email-cell">{s.phone}</div>}
              </td>
              <td>
                <div className="actions-cell">
                  <button className="btn btn-edit-ghost" onClick={() => onEdit(s)}>
                    Edit
                  </button>
                  <button className="btn btn-danger-ghost" onClick={() => onDelete(s)}>
                    Delete
                  </button>
                </div>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
